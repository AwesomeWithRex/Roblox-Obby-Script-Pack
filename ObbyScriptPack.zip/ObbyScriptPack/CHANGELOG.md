# CHANGELOG FOR OBBY SCRIPT PACK

## This info contains all of the changes.

### New scripts
- Falling part

### Bug Fixes
- Fixed the fade block not working I forgot to add the variable for the part... whoops!

### Other new stuff
- Added a .rbxl file with all the examples inside. It can be found in the place folder.
- Added .rbxm files with all the already made stuff inside. It can found in the models
folder.