# README FOR OBBY SCRIPTPACK
![](stuff/Icon.png)
[#how to use](#How to use the scripts)
[#requirements](#requirements)
## This contains all info you need.

### How to use the scripts
So basically all the scripts so far are all supposed to be put in parts.
If any issues, questions, or ideas please leave them on gamebanana or github[MIGHT BE COMING THERE SOON ;)]
### Requirements
You have to be on Windows or Mac... I'm not sure about Linux.
You have to have a Roblox account [duh] and you have to have Roblox Studio.